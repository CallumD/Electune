require 'test_helper'

class PlaylistHelperTest < ActionView::TestCase
end
