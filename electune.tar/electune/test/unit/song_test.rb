require_relative '../../lib/song'

describe Song, "#voting" do

  let(:song) { song = Song.new }

  it "should have one vote when initialised" do
    song.votes.should eq(1)
  end
 
  it "should increase the votes when upvoted" do
    song.upvote
    song.votes.should eq(2)
  end

  it "should decreate the votes when vitoed" do
   song.vito
   song.votes.should eq(0)
  end
end


