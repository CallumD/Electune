# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Electune::Application.config.secret_token = '1bd67fc71a0962fb70f5b2505f46e5c13b433740e8e30e3c50b04a2f09a81b67450a8bb673fba0b6eae0f610ce938eea8c08a5f4047467046d313f87f1a0af44'
