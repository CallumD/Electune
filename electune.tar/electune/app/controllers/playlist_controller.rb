class PlaylistController < ApplicationController
  def show

  end
end
